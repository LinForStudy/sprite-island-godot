本包包含 UI 参考页面、自动切分的 UI 组件和 Godot 接入计划。请优先阅读 GODOT_UI_MAP_PLAN.md。
